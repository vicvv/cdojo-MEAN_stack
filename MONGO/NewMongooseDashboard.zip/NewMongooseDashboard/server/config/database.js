module.exports = {
  database:'mongodb://localhost/mypetsdb',
  secret: 'yoursecret'  
}
