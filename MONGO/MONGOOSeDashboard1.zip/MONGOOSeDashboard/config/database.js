module.exports = {
    database:'mongodb://localhost:27017/mongooses',
    secret: 'yoursecret'
  }