module.exports = {
    database:'mongodb://localhost/nodekb',
    secret: 'yoursecret'
  }
