const express  = require("express");
const app      = express();
const server   = app.listen(8000);
const path = require('path');
const flash    = require('express-flash');

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/myuserdb', { useNewUrlParser: true } );

// Use native promises. For what???
mongoose.Promise = global.Promise;

// for what??
app.use(require("express-session")({
    secret:"Twhatever",
    resave: false,
    saveUninitialized: false
}));

// how??
app.use(flash());

app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(express.urlencoded({extended: true}));


var QuoteSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 2 },
    quote: {type: String, required: true, minlength: 2}}, 
    {timestamps: true}
    );
mongoose.model('Quote', QuoteSchema); 
var Quote = mongoose.model('Quote');   



app.get('/', (req, res) => {  
       res.render("index");       
});

// app.post('/add', (req, res)  =>{
//     console.log("POST DATA", req.body);
//     var quote = new Quote({name: req.body.name, quote: req.body.quote});
//     quote.save(function(err) {
//       if(err) {
//         console.log('something went wrong');
//         console.log(quote.errors);
//         res.render('index', {errors: quote.errors});
//       } 
//       else { 
//         console.log('successfully added a quote!');
//         res.redirect('/result');
//       }
//     });
//   });
  
// app.get('/result',(req, res) => {
//     arr = Quote.find({}, function(err, quotes) {
//         console.log('array??? really???:,' ,arr);
//         res.render('result', {arr:quotes});
//     });
// });

 
app.post('/add', (req, res) => {
    const quote = new Quote(req.body);
    quote.name = req.body.name;
    quote.quote = req.body.quote;
    quote.save()
        //.then(newQuoteData => console.log('quote created: ', newQuoteData))
        .then(() => res.redirect('/result'))         
        .catch(err => {
            console.log("We have an error!", err);
            // adjust the code below as needed to create a flash message with the tag and content you would like
            for (var key in err.errors) {
                req.flash('quote', err.errors[key].message);
            }
            res.redirect('/');
        });
});

app.get('/result', (req, res) => {  
    data = Quote.find()
        .then(data => res.render("result", {quotes: data}))
        .catch(err => res.json(err));
});

