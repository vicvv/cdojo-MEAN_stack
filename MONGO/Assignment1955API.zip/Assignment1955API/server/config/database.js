module.exports = {
  database:'mongodb://localhost/person',
  secret: 'yoursecret'
}
